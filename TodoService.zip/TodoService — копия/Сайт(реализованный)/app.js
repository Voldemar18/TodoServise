class TodoApp {
    constructor() {
        this.API_URL = 'http://127.0.0.1:8080/api/todos';
        this.currentFilter = 'all';
        this.editingTaskId = null;
        this.viewTaskId = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadTasks();
    }

    setupEventListeners() {
        const titleInput = document.getElementById('taskTitle');
        const descInput = document.getElementById('taskDesc');
        
        if (titleInput) {
            titleInput.addEventListener('input', (e) => {
                const count = document.getElementById('titleCount');
                if (count) count.textContent = `${e.target.value.length}/100`;
            });

            titleInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.addTask();
            });
        }

        if (descInput) {
            descInput.addEventListener('input', (e) => {
                const count = document.getElementById('descCount');
                if (count) count.textContent = `${e.target.value.length}/10000`;
            });
        }
    }

    async makeRequest(url, options = {}) {
        try {
            const response = await fetch(url, {
                method: options.method || 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers,
                },
                body: options.body
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('Request failed:', error);
            throw new Error('Не удалось подключиться к серверу');
        }
    }

    async loadTasks() {
        try {
            this.showLoading(true);
            const tasks = await this.makeRequest(this.API_URL);
            this.displayTasks(tasks);
            this.applyFilter();
            this.updateStats(tasks);
        } catch (error) {
            this.showTasksError(error.message);
        } finally {
            this.showLoading(false);
        }
    }

    showLoading(show) {
        const loading = document.getElementById('loading');
        const tasksList = document.getElementById('tasksList');
        
        if (loading) loading.classList.toggle('hidden', !show);
        if (tasksList && show) tasksList.innerHTML = '';
    }

    displayTasks(tasks) {
        const container = document.getElementById('tasksList');
        if (!container) return;
        
        if (!tasks || tasks.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-rocket"></i>
                    <h3>Миссий пока нет</h3>
                    <p>Добавьте первую космическую задачу!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = tasks.map(task => `
            <div class="task-item holographic-card ${task.isCompleted ? 'completed' : ''}" onclick="app.openTaskView('${task.id}')">
                <div class="task-header">
                    <div class="task-checkbox" onclick="event.stopPropagation()">
                        <input type="checkbox" ${task.isCompleted ? 'checked' : ''} 
                               onchange="app.toggleTask('${task.id}', ${!task.isCompleted})">
                    </div>
                    <div class="task-content">
                        <div class="task-title">${this.escapeHtml(task.title)}</div>
                        ${task.description ? `<div class="task-desc">${this.escapeHtml(this.truncateText(task.description, 100))}</div>` : ''}
                        <div class="task-meta">
                            <i class="far fa-calendar"></i> ${new Date(task.createdAt).toLocaleDateString('ru-RU')}
                            ${task.isCompleted ? ' | ✅ Выполнена' : ' | 🔄 Активна'}
                        </div>
                        <div class="task-actions" onclick="event.stopPropagation()">
                            <button class="btn-primary holographic-btn" onclick="app.editTask('${task.id}')">
                                <i class="fas fa-edit"></i> Изменить
                            </button>
                            <button class="btn-danger holographic-btn" onclick="app.deleteTask('${task.id}')">
                                <i class="fas fa-trash-alt"></i> Удалить
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }

    updateStats(tasks) {
        const stats = document.getElementById('stats');
        if (!stats) return;
        
        const total = tasks.length;
        const completed = tasks.filter(task => task.isCompleted).length;
        const active = total - completed;

        stats.innerHTML = `
            <span class="stat">Всего: <strong>${total}</strong></span>
            <span class="stat">Выполнено: <strong>${completed}</strong></span>
            <span class="stat">Активные: <strong>${active}</strong></span>
        `;
    }

    async addTask() {
        const titleInput = document.getElementById('taskTitle');
        const descInput = document.getElementById('taskDesc');
        
        const title = titleInput.value.trim();
        const description = descInput.value.trim();

        if (!title) {
            this.showNotification('Введите название задачи', 'error');
            return;
        }

        try {
            await this.makeRequest(this.API_URL, {
                method: 'POST',
                body: JSON.stringify({ title, description })
            });

            titleInput.value = '';
            descInput.value = '';
            this.showNotification('Задача добавлена!', 'success');
            this.loadTasks();
        } catch (error) {
            this.showNotification('Ошибка при добавлении задачи', 'error');
        }
    }

    async deleteTask(id) {
        if (!confirm('Удалить задачу?')) return;

        try {
            await this.makeRequest(`${this.API_URL}/${id}`, { method: 'DELETE' });
            this.showNotification('Задача удалена', 'success');
            
            await this.loadTasks();
        } catch (error) {
            this.showNotification('Ошибка при удалении задачи', 'error');
            console.error('Delete error:', error);
        }
    }

    async toggleTask(id, isCompleted) {
        try {
            const task = await this.makeRequest(`${this.API_URL}/${id}`);
            
            await this.makeRequest(`${this.API_URL}/${id}`, {
                method: 'PUT',
                body: JSON.stringify({
                    title: task.title,
                    description: task.description,
                    isCompleted: isCompleted
                })
            });

            await this.loadTasks();
        } catch (error) {
            this.showNotification('Ошибка при обновлении задачи', 'error');
            this.loadTasks();
        }
    }

    editTask(id) {
        this.editingTaskId = id;
        this.openEditModal(id);
    }

    async openEditModal(id) {
        try {
            const task = await this.makeRequest(`${this.API_URL}/${id}`);
            const modal = document.getElementById('editModal');
            const titleInput = document.getElementById('editTitle');
            const descInput = document.getElementById('editDesc');
            
            if (titleInput) titleInput.value = task.title;
            if (descInput) descInput.value = task.description || '';
            if (modal) modal.classList.remove('hidden');
        } catch (error) {
            this.showNotification('Ошибка при загрузке задачи для редактирования', 'error');
        }
    }

    async saveEditedTask() {
        if (!this.editingTaskId) return;

        const titleInput = document.getElementById('editTitle');
        const descInput = document.getElementById('editDesc');
        
        const title = titleInput.value.trim();
        const description = descInput.value.trim();

        if (!title) {
            this.showNotification('Введите название задачи', 'error');
            return;
        }

        try {
            const currentTask = await this.makeRequest(`${this.API_URL}/${this.editingTaskId}`);
            
            await this.makeRequest(`${this.API_URL}/${this.editingTaskId}`, {
                method: 'PUT',
                body: JSON.stringify({
                    title,
                    description,
                    isCompleted: currentTask.isCompleted
                })
            });

            this.closeEditModal();
            this.showNotification('Задача обновлена!', 'success');
            this.loadTasks();
        } catch (error) {
            this.showNotification('Ошибка при обновлении задачи', 'error');
        }
    }

    closeEditModal() {
        const modal = document.getElementById('editModal');
        if (modal) modal.classList.add('hidden');
        this.editingTaskId = null;
    }

    // app.js - обновите метод openTaskView
    async openTaskView(id) {
        try {
            const task = await this.makeRequest(`${this.API_URL}/${id}`);
            const modal = document.getElementById('viewModal');
            const titleElement = document.getElementById('viewTitle');
            const descElement = document.getElementById('viewDesc');
            const metaElement = document.getElementById('viewMeta');
            const statusElement = document.getElementById('viewStatus');
            
            if (titleElement) titleElement.textContent = task.title;
            
            if (descElement) {
                if (task.description && task.description.trim()) {
                    descElement.textContent = task.description;
                    descElement.style.fontStyle = 'normal';
                    descElement.style.color = '#cbd5e1';
                    descElement.style.whiteSpace = 'pre-wrap';
                    descElement.style.wordWrap = 'break-word';
                    
                    // Принудительно показываем скроллбар если контент превышает высоту
                    setTimeout(() => {
                        if (descElement.scrollHeight > descElement.clientHeight) {
                            descElement.style.overflowY = 'auto';
                        } else {
                            descElement.style.overflowY = 'hidden';
                        }
                    }, 100);
                    
                } else {
                    descElement.textContent = 'Описание отсутствует';
                    descElement.style.fontStyle = 'italic';
                    descElement.style.color = '#94a3b8';
                    descElement.style.whiteSpace = 'normal';
                    descElement.style.overflowY = 'hidden';
                }
            }
            
            if (metaElement) {
                metaElement.innerHTML = `
                    <div><i class="far fa-calendar"></i> Создано: ${new Date(task.createdAt).toLocaleString('ru-RU')}</div>
                    ${task.updatedAt && task.updatedAt !== task.createdAt ? 
                        `<div><i class="fas fa-sync-alt"></i> Обновлено: ${new Date(task.updatedAt).toLocaleString('ru-RU')}</div>` : ''}
                    <div><i class="far fa-clock"></i> ID: ${task.id}</div>
                `;
            }
            
            if (statusElement) {
                statusElement.textContent = task.isCompleted ? '✅ Выполнена' : '🔄 Активна';
                statusElement.className = task.isCompleted ? 'completed' : 'active';
            }
            
            if (modal) modal.classList.remove('hidden');
        } catch (error) {
            this.showNotification('Ошибка при загрузке задачи', 'error');
        }
    }

    // Добавьте этот метод для форматирования описания
    formatDescription(text) {
        if (!text) return '';
        
        // Заменяем переносы строк на теги <br> и обрабатываем специальные символы
        return this.escapeHtml(text)
            .replace(/\r\n|\r|\n/g, '<br>')
            .replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;')
            .replace(/  /g, ' &nbsp;');
    }


    closeViewModal() {
        const modal = document.getElementById('viewModal');
        if (modal) modal.classList.add('hidden');
        this.viewTaskId = null;
    }

    setFilter(filter) {
        this.currentFilter = filter;
        
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        const activeBtn = document.querySelector(`.filter-btn[onclick="setFilter('${filter}')"]`);
        if (activeBtn) activeBtn.classList.add('active');
        
        this.applyFilter();
    }

    async applyFilter() {
        try {
            const tasks = await this.makeRequest(this.API_URL);
            let filteredTasks = tasks;

            switch (this.currentFilter) {
                case 'active':
                    filteredTasks = tasks.filter(task => !task.isCompleted);
                    break;
                case 'completed':
                    filteredTasks = tasks.filter(task => task.isCompleted);
                    break;
                case 'all':
                default:
                    filteredTasks = tasks;
                    break;
            }

            this.displayTasks(filteredTasks);
            this.updateStats(tasks);
        } catch (error) {
            this.showTasksError(error.message);
        }
    }

    async clearCompleted() {
        try {
            const tasks = await this.makeRequest(this.API_URL);
            const completedTasks = tasks.filter(task => task.isCompleted);
            
            if (completedTasks.length === 0) {
                this.showNotification('Нет выполненных задач для удаления', 'info');
                return;
            }

            if (!confirm(`Удалить ${completedTasks.length} выполненных задач?`)) return;

            const deletePromises = completedTasks.map(task => 
                this.makeRequest(`${this.API_URL}/${task.id}`, { 
                    method: 'DELETE' 
                })
            );

            await Promise.all(deletePromises);

            this.showNotification(`Удалено ${completedTasks.length} выполненных задач`, 'success');
            
            await this.loadTasks();
        } catch (error) {
            this.showNotification('Ошибка при удалении выполненных задач', 'error');
            console.error('Clear completed error:', error);
        }
    }

    showTasksError(message) {
        const container = document.getElementById('tasksList');
        if (!container) return;
        
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Ошибка загрузки</h3>
                <p>${message}</p>
                <button class="holographic-btn btn-primary" onclick="app.loadTasks()">Попробовать снова</button>
            </div>
        `;
    }

    showNotification(message, type = 'success') {
        const notification = document.getElementById('notification');
        if (!notification) return;
        
        notification.textContent = message;
        notification.className = `notification ${type}`;
        notification.classList.remove('hidden');

        setTimeout(() => {
            notification.classList.add('hidden');
        }, 3000);
    }

    escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    truncateText(text, maxLength) {
        if (!text) return '';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }
}

// Инициализация приложения
document.addEventListener('DOMContentLoaded', function() {
    window.app = new TodoApp();
});

// Глобальные функции для HTML атрибутов
window.addTask = function() { window.app.addTask(); }
window.setFilter = function(filter) { window.app.setFilter(filter); }
window.clearCompleted = function() { window.app.clearCompleted(); }
window.closeEditModal = function() { window.app.closeEditModal(); }
window.saveEditedTask = function() { window.app.saveEditedTask(); }
window.closeViewModal = function() { window.app.closeViewModal(); }