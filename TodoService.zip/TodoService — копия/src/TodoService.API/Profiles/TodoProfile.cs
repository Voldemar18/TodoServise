using AutoMapper;
using TodoService.API.Models;
using TodoService.API.DTOs;

namespace TodoService.API.Profiles;

public class TodoProfile : Profile
{
    public TodoProfile()
    {
        // CreateTodoDto -> TodoItem
        CreateMap<CreateTodoDto, TodoItem>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(_ => Guid.NewGuid()))
            .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(_ => DateTime.UtcNow))
            .ForMember(dest => dest.UpdatedAt, opt => opt.Ignore()) // Устанавливаем в null через Ignore, а в контроллере явно
            .ForMember(dest => dest.IsCompleted, opt => opt.MapFrom(_ => false))
            .AfterMap((src, dest) => dest.UpdatedAt = null); // Явно устанавливаем UpdatedAt в null

        // UpdateTodoDto -> TodoItem
        CreateMap<UpdateTodoDto, TodoItem>()
            .ForMember(dest => dest.UpdatedAt, opt => opt.MapFrom(_ => DateTime.UtcNow))
            .ForAllMembers(opts => opts.Condition((src, dest, srcMember) => srcMember != null));

        // TodoItem -> TodoDto
        CreateMap<TodoItem, TodoDto>();
    }
}