using Microsoft.EntityFrameworkCore;
using TodoService.API.Models;

var builder = WebApplication.CreateBuilder(args);

// Сервисы
builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddAutoMapper(typeof(Program).Assembly);
builder.Services.AddDbContext<TodoContext>(opt => opt.UseInMemoryDatabase("TodoList"));

// Добавляем CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Используем CORS
app.UseCors("AllowAll");

// Мидлвары
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Обслуживание статических файлов (веб-интерфейса)
app.UseStaticFiles();

app.UseHttpsRedirection();
app.UseAuthorization();

// Кастомный мидлвар для исключений
app.Use(async (context, next) =>
{
    try
    {
        await next();
    }
    catch (Exception ex)
    {
        context.Response.StatusCode = 500;
        await context.Response.WriteAsync($"Error: {ex.Message}");
    }
});

app.MapControllers();

// Fallback route для SPA
app.MapFallbackToFile("index.html");

app.Run();