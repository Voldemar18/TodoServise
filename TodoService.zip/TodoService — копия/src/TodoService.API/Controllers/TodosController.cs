using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using TodoService.API.Models;
using TodoService.API.DTOs;

namespace TodoService.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TodosController : ControllerBase
{
    private readonly TodoContext _context;
    private readonly IMapper _mapper;

    public TodosController(TodoContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    // GET: api/todos
    [HttpGet]
    public async Task<ActionResult<IEnumerable<TodoDto>>> GetTodos()
    {
        var todos = await _context.Todos.ToListAsync();
        var todoDtos = _mapper.Map<IEnumerable<TodoDto>>(todos);
        return Ok(todoDtos);
    }

    // GET: api/todos/{id}
    [HttpGet("{id}")]
    public async Task<ActionResult<TodoDto>> GetTodo(Guid id)
    {
        var todo = await _context.Todos.FindAsync(id);

        if (todo == null)
        {
            return NotFound();
        }

        var todoDto = _mapper.Map<TodoDto>(todo);
        return todoDto;
    }

    // POST: api/todos
    [HttpPost]
    public async Task<ActionResult<TodoDto>> PostTodo(CreateTodoDto createTodoDto)
    {
        var todoItem = _mapper.Map<TodoItem>(createTodoDto);

        _context.Todos.Add(todoItem);
        await _context.SaveChangesAsync();

        var todoDto = _mapper.Map<TodoDto>(todoItem);

        return CreatedAtAction(nameof(GetTodo), new { id = todoDto.Id }, todoDto);
    }

    // PUT: api/todos/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> PutTodo(Guid id, UpdateTodoDto updateTodoDto)
    {
        var todoItem = await _context.Todos.FindAsync(id);
        if (todoItem == null)
        {
            return NotFound();
        }

        _mapper.Map(updateTodoDto, todoItem); // Обновляем поля существующего объекта
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // DELETE: api/todos/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteTodo(Guid id)
    {
        var todoItem = await _context.Todos.FindAsync(id);
        if (todoItem == null)
        {
            return NotFound();
        }

        _context.Todos.Remove(todoItem);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}